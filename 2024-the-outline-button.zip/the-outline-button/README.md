# The outline button

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/ExOgqOE](https://codepen.io/ainalem/pen/ExOgqOE).

Adding Spark to Interactions ✨💡 Experience the captivating allure of an animated outline on this interactive button! Watch as the vibrant strokes dance around, amplifying the user experience. Elevate your web design with this enchanting effect!